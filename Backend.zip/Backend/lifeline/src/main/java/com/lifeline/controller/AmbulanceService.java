package com.lifeline.controller;

public class AmbulanceService {

}
