package com.lifeline.model;

public @interface AllArgsConstructor {

}
