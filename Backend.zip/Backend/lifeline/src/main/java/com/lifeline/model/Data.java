package com.lifeline.model;

public @interface Data {

}
