package com.lifeline.model;

public @interface NoArgsConstructor {

}
